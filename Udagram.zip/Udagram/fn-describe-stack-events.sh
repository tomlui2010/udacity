aws cloudformation describe-stack-events \
--stack-name $1