aws s3 cp docker-awslayer/python.zip s3://$1/python.zip
