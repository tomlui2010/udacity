S3 static website: 
http://myudacitydevopsbucket0413.s3-website-us-east-1.amazonaws.com

Cloudfront url:
https://d2zn6o8whysbdj.cloudfront.net