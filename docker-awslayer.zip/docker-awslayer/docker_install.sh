virtualenv --python=/usr/bin/python3.8 python
source python/bin/activate
pip3 install -r requirements.txt -t python/lib/python3.8/site-packages

zip -r python.zip python